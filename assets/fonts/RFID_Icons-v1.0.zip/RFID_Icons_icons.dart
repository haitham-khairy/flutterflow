// Place fonts/RFID_Icons.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: RFID_Icons
//      fonts:
//       - asset: fonts/RFID_Icons.ttf
import 'package:flutter/widgets.dart';

class RFID_Icons {
  RFID_Icons._();

  static const String _fontFamily = 'RFID_Icons';

  static const IconData RFID_Icon = IconData(0xe900, fontFamily: _fontFamily);
}
